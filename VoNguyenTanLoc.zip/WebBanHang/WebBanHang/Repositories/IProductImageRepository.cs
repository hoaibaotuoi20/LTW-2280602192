﻿namespace WebBanHang.Repositories
{
    public interface IProductImage
    {
    }
}
