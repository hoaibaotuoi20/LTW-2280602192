﻿namespace WebBanHang.Repositories
{
    public class EFProductImageRepository
    {
    }
}
