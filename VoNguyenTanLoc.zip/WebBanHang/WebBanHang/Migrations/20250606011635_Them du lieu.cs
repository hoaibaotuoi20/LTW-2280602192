﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebBanHang.Migrations
{
    /// <inheritdoc />
    public partial class Themdulieu : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
            table: "Categories",
            columns: new[] { "Id", "Name" },
            values: new object[,]
            {
                { 1, "Trái cây nhiệt đới" },
                { 2, "Trái cây nhập khẩu" },
                { 3, "Trái cây sạch" },
                { 4, "Trái cây họ cam quýt" },
                { 5, "Trái cây hạt" },
                { 6, "Trái cây đặc sản" }
            });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
